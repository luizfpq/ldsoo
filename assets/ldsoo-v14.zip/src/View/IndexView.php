<?php

class IndexView
{

	const indexRoute = 'view/index/index.php';

  	public function __construct(){}
  
  	public function getIndexRoute(){

    	return self::indexRoute;
  	}
 

}