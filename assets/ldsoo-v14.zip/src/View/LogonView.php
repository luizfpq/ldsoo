<?php

class LogonView
{
	const logonRoute = 'view/logon/logon.php';

  public function __construct(){}

  public function getLogonRoute(){

    return self::logonRoute;
  }

  
}